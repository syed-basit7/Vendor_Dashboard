const borderedDiv = {
  border: "1px solid #E9E7FD",
  padding: 10,
  marginBottom: 10,
  borderRadius: 4,
};

export default borderedDiv;
