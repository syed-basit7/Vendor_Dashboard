const headingStyle = {
  color: "#23272E",
  fontSize: 18,
  margin: 0,
};

export const viewAllStyle = {
  color: "#0F60FF",
  fontSize: 14,
  fontWeight: 600,
};

export const viewDetailForTable = {
  color: "#0F60FF",
  fontWeight: 400,
  fontSize: 15,
  margin: 0,
  cursor: "pointer",
};

export default headingStyle;
