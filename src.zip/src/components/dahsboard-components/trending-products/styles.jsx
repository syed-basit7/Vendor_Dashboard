const trendingSubHeading = {
  color: "#8B909A",
  fontSize: 14,
  fontWeight: 500,
};

export default trendingSubHeading;
