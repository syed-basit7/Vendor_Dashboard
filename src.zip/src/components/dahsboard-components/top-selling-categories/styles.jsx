const categoryNameStyle = {
  textAlign: "center",
  fontSize: "0.8vw",
  fontWeight: 500,
  color: "#CFDFFF",
};

export const cashStyle = {
  textAlign: "center",
  fontSize: "2vw",
  fontWeight: 700,
  color: "white",
};

export const perDayStyle = {
  textAlign: "center",
  fontSize: "0.8vw",
  fontWeight: 500,
  color: "#CFDFFF",
};

export const circleStyle = {
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
};

export default categoryNameStyle;
