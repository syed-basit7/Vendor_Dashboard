const dashboardCardContainer = {
  backgroundColor: "#FFFFFF",
  borderRadius: 10,
};

export default dashboardCardContainer;
