const pagesSelectorHeadings = {
  color: "#8B909A",
  fontSize: 15,
  fontWeight: 500,
  margin: 0,
};

export default pagesSelectorHeadings;
