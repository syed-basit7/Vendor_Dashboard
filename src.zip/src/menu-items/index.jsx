import dashboard from "./dashboard";
import product from "./product";
import adminManagement from "./admin";

const menuItems = {
  items: [dashboard, product, adminManagement],
};

export default menuItems;
